package hello.tests

import kotlin.test.assertEquals
import org.junit.Test

class HelloTest {
    
}
